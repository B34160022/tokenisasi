# 23419035_tokenization
Simple Tokenization in HTML and JavaScript.

# UTS Teori Bahasa Formal dan Otomata

Nama      : Muhammad Ibrahiem Adham</br>
NIM       : 23460022</br>
Prodi     : Teknik Informatika</br>
Angkatan  : 2019 Malam</br>
